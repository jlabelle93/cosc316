//
//  GameViewController.swift
//  CS316_Final_Project
//
//  Created by Jacob Labelle on 2024-04-05.
//

import UIKit

class GameViewController: UIViewController {
    
    // All the lovely buttons
    @IBOutlet weak var aBtn: UIButton!
    @IBOutlet weak var bBtn: UIButton!
    @IBOutlet weak var cBtn: UIButton!
    @IBOutlet weak var dBtn: UIButton!
    @IBOutlet weak var eBtn: UIButton!
    @IBOutlet weak var fBtn: UIButton!
    @IBOutlet weak var gBtn: UIButton!
    @IBOutlet weak var hBtn: UIButton!
    @IBOutlet weak var iBtn: UIButton!
    @IBOutlet weak var jBtn: UIButton!
    @IBOutlet weak var kBtn: UIButton!
    @IBOutlet weak var lBtn: UIButton!
    @IBOutlet weak var mBtn: UIButton!
    @IBOutlet weak var nBtn: UIButton!
    @IBOutlet weak var oBtn: UIButton!
    @IBOutlet weak var pBtn: UIButton!
    @IBOutlet weak var qBtn: UIButton!
    @IBOutlet weak var rBtn: UIButton!
    @IBOutlet weak var sBtn: UIButton!
    @IBOutlet weak var tBtn: UIButton!
    @IBOutlet weak var uBtn: UIButton!
    @IBOutlet weak var vBtn: UIButton!
    @IBOutlet weak var wBtn: UIButton!
    @IBOutlet weak var xBtn: UIButton!
    @IBOutlet weak var yBtn: UIButton!
    @IBOutlet weak var zBtn: UIButton!
    var letterButtons: [UIButton] = []
    // End all the buttons
    @IBOutlet weak var newGameBtn: UIButton!
    @IBOutlet weak var exitBtn: UIButton!
    
    @IBOutlet weak var hangmanImg: UIImageView!
    var imgArray: [UIImage] = []
    @IBOutlet weak var wordLabel: UILabel!
    @IBOutlet weak var incorrectGuessLabel: UILabel!
    @IBOutlet weak var guessWordBtn: UIButton!
    @IBOutlet weak var incGuessesLabel: UILabel!
    
    // Game variables
    var word_to_guess: String = ""
    var hidden_word: [String] = []
    var guesses: Int = 5
    var isOver: Bool = false
    var guessEntered: String = ""
    let hangmanDict: HangmanWords = HangmanWords.init()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Load all the buttons into an array to make life easier
        letterButtons.append(aBtn)
        letterButtons.append(bBtn)
        letterButtons.append(cBtn)
        letterButtons.append(dBtn)
        letterButtons.append(eBtn)
        letterButtons.append(fBtn)
        letterButtons.append(gBtn)
        letterButtons.append(hBtn)
        letterButtons.append(iBtn)
        letterButtons.append(jBtn)
        letterButtons.append(kBtn)
        letterButtons.append(lBtn)
        letterButtons.append(mBtn)
        letterButtons.append(nBtn)
        letterButtons.append(oBtn)
        letterButtons.append(pBtn)
        letterButtons.append(qBtn)
        letterButtons.append(rBtn)
        letterButtons.append(sBtn)
        letterButtons.append(tBtn)
        letterButtons.append(uBtn)
        letterButtons.append(vBtn)
        letterButtons.append(wBtn)
        letterButtons.append(xBtn)
        letterButtons.append(yBtn)
        letterButtons.append(zBtn)
        // All the buttons are loaded now
        // Swap fonts
        wordLabel.font = UIFont(name: "PermanentMarker-Regular", size: 30)
        incGuessesLabel.font = UIFont(name: "PermanentMarker-Regular", size: 22)
        incorrectGuessLabel.font = UIFont(name: "PermanentMarker-Regular", size: 20)
        // Buttons and fonts were super finicky
        /*
        guessWordBtn.titleLabel?.font = UIFont(name: "PermanentMarker-Regular", size: 18)
        newGameBtn.titleLabel?.font = UIFont(name: "PermanentMarker-Regular", size: 14)
        exitBtn.titleLabel?.font = UIFont(name: "PermanentMarker-Regular", size: 14)
        */
        // Populate the images
        imgArray.append(UIImage(named: "wg-1.png")!)
        imgArray.append(UIImage(named: "wg-2.png")!)
        imgArray.append(UIImage(named: "wg-3.png")!)
        imgArray.append(UIImage(named: "wg-4.png")!)
        imgArray.append(UIImage(named: "wg-5.png")!)
        imgArray.append(UIImage(named: "wg-6.png")!)
        imgArray.append(UIImage(named: "wg-7.png")!)
        imgArray.append(UIImage(named: "game-over.png")!)
        // Start the game
        newGame()
    }
    
    @IBAction func startNewGame(_ sender: Any) {
        viewDidLoad()
    }
    
    func newGame() {
        // Reset UI Elements
        wordLabel.text = ""
        incorrectGuessLabel.text = ""
        for i in letterButtons {
            i.isHidden = false
            //i.titleLabel?.font = UIFont(name: "PermanentMarker-Regular", size: 16)
        }
        hangmanImg.image = imgArray[0]
        
        // Reset Game Elements
        isOver = false
        guessEntered = ""
        word_to_guess = hangmanDict.getRandomWord()
        guesses = 7
        hidden_word = [String](repeating: "_", count: word_to_guess.count)
        
        // Set the display elements now that the game is ready
        wordLabel.text = hidden_word.joined(separator: " ")
    }
    
    @IBAction func onLetterPress(_ sender: UIButton) {
        sender.isHidden = true
        //debugPrint(sender.titleLabel!.text!)
        makeGuess(sender.titleLabel!.text!)
    }
    
    @IBAction func guessWord(_ sender: UIButton) {
        displayGuessWord { guessText in
            if let guess = guessText {
                let upperGuess = guess.uppercased()
                //debugPrint(upperGuess)
                self.guessEntered = upperGuess
                self.gameStatusCheck()
            }
        }
    }
    
    private func makeGuess(_ letter: String) {
        if !(word_to_guess.contains(letter)) {
            guesses -= 1
            updateImageView()
            updateGuessLabel(letter)
            gameStatusCheck()
        } else {
            revealLetter(Character(letter))
            gameStatusCheck()
        }
    }
    
    private func gameStatusCheck() {
        if (guesses < 1) {
            isOver = true
            displayGameOver()
        }
        if (!(hidden_word.contains("_")) && guesses > 0) {
            isOver = true
            displayGameWin()
        }
        if (guessEntered == word_to_guess) && (guesses > 0) {
            isOver = true
            displayGameWin()
        }
        if (guessEntered != word_to_guess) && (guessEntered != "") {
            isOver = true
            guesses = 0
            updateImageView()
            displayGameOver()
        }
    }
    
    private func revealLetter(_ letter: Character) {
        var index = 0
        for c in word_to_guess {
            if (c == letter) {
                hidden_word[index] = String(c)
            }
            index += 1
        }
        wordLabel.text = hidden_word.joined(separator: " ")
    }
    
    // UI Update functions
    private func updateGuessLabel(_ letter: String) {
        var guessText = incorrectGuessLabel.text!
        guessText = guessText + " " + letter
        incorrectGuessLabel.text = guessText
    }
    
    private func updateImageView() {
        let img_index = guesses
        switch img_index {
        case 6:
            hangmanImg.image = imgArray[1]
        case 5:
            hangmanImg.image = imgArray[2]
        case 4:
            hangmanImg.image = imgArray[3]
        case 3:
            hangmanImg.image = imgArray[4]
        case 2:
            hangmanImg.image = imgArray[5]
        case 1:
            hangmanImg.image = imgArray[6]
        case 0:
            hangmanImg.image = imgArray[7]
        default:
            break
        }
    }
    
    
    // Alert displays for Game Over, Game Win, and Guess pop up boxes
    private func displayGameOver() {
        let alertMsg = "Game over. The word was " + word_to_guess + "."
        
        let gameOverAlert = UIAlertController(title: "Game Over", message: alertMsg, preferredStyle: .alert)
        
        let exitAction = UIAlertAction(title: "Exit", style: .cancel) { _ in
            self.dismiss(animated: true)
        }
        
        let newGameAction = UIAlertAction(title: "New Game", style: .default) { _ in
            self.viewDidLoad()
        }
        
        gameOverAlert.addAction(exitAction)
        gameOverAlert.addAction(newGameAction)
        
        self.present(gameOverAlert, animated: true, completion: nil)
    }
    
    private func displayGameWin() {
        let alertMsg = "You guessed the word! The word was " + word_to_guess + "."
        let gameWinAlert = UIAlertController(title: "You Won!", message: alertMsg, preferredStyle: .alert)
        
        let exitAction = UIAlertAction(title: "Exit", style: .cancel) { _ in
            self.dismiss(animated: true)
        }
        
        let newGameAction = UIAlertAction(title: "New Game", style: .default) { _ in
            self.viewDidLoad()
        }
        
        gameWinAlert.addAction(exitAction)
        gameWinAlert.addAction(newGameAction)
        
        self.present(gameWinAlert, animated: true)
    }
    
    private func displayGuessWord(completion: @escaping (String?) -> Void) {
        let alertMsg = "Enter your guess:"
        
        let guessAlert = UIAlertController(title: "Guess the word!", message: alertMsg, preferredStyle: .alert)
        
        guessAlert.addTextField {
            (textField) in textField.placeholder = "Enter your guess"
        }
        
        let guessAction = UIAlertAction(title: "Guess", style: .default) {[weak guessAlert] _ in
            if let textField = guessAlert?.textFields?.first, let enteredText = textField.text {
                completion(enteredText)
            } else {
                completion(nil)
            }
        }
        
        let exitToGameAction = UIAlertAction(title: "Return to Game", style: .cancel) { _ in
            completion(nil)
        }
        
        guessAlert.addAction(guessAction)
        guessAlert.addAction(exitToGameAction)
        
        self.present(guessAlert, animated: true, completion: nil)
    }
    
}
