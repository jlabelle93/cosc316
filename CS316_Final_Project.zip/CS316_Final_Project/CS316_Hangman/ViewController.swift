//
//  ViewController.swift
//  CS316_Final_Project
//
//  Created by Jacob Labelle on 2024-04-05.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var startBtn: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        titleLabel.font = UIFont(name: "PermanentMarker-Regular", size: 45)
    }
}

