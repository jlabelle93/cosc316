//
//  HangmanWords.swift
//  CS316_Final_Project
//
//  Created by Jacob Labelle on 2024-04-05.
//

import Foundation

class HangmanWords {
    var word_dict: [String]
    var db_path: String = String()
    
    // Load all words for use.
    init() {
        // Pull words from file or use backup list
        let filepath = Bundle.main.path(forResource: "dictionary", ofType: "txt")
        if let path = filepath {
            let word_file = try! String(contentsOfFile: path)
            
            word_dict = word_file.components(separatedBy: "\r\n")
        } else {
            word_dict = ["Okanagan", "College", "Goodbye", "Computer", "Science"]
        }
        debugPrint("Words loaded into dict.")
        /* Using a database took too long to load. Loading the words into a dictionary direct from file was much
           faster than the SQLite alternative.
         
        // Init database to store words
        let filemgr = FileManager.default
        let dirPaths = filemgr.urls(for: .documentDirectory, in: .userDomainMask)
        db_path = dirPaths[0].appendingPathComponent("words.db").path
        
        if !filemgr.fileExists(atPath: db_path as String) {
            let wordsDB = FMDatabase(path: db_path as String)
            if (wordsDB.open()) {
                // Create the database
                let sql_stmt = "CREATE TABLE IF NOT EXISTS WORDS (ID INTEGER PRIMARY KEY AUTOINCREMENT, WORD TEXT)"
                if !(wordsDB.executeStatements(sql_stmt)) {
                    print("Error: \(wordsDB.lastErrorMessage())")
                }
                // Load DB with the words
                for word in word_dict {
                    let ins_stmt = "INSERT INTO WORDS (WORD) VALUES ('\(word)')"
                    if !(wordsDB.executeUpdate(ins_stmt, withArgumentsIn: [])) {
                        print("Error: \(wordsDB.lastErrorMessage())")
                    }
                }
                debugPrint("Words loaded.")
                // Close the database
                wordsDB.close()
            } else {
                print("Error: \(wordsDB.lastErrorMessage())")
            }
        }
         */
    }

    // Randomly select a word.
    func getRandomWord() -> String {
        var selectedWord: String = ""
        /* This code would be used in the event the database wasn't a super slow method.
        let wordsDB = FMDatabase(path: db_path as String)
        if !(wordsDB.open()) {
            repeat {
                let id = Int(arc4random_uniform(UInt32(word_dict.count)))
                let word_stmt = "SELECT WORD FROM WORDS WHERE ID = '\(id)')"
                let result: FMResultSet? = wordsDB.executeQuery(word_stmt, withArgumentsIn: [])
                if result?.next() == true {
                    selectedWord = (result?.string(forColumn: "WORD"))!
                }
            } while (selectedWord.count > 8)
        }
        wordsDB.close()
        */
        repeat {
            let id = Int(arc4random_uniform(UInt32(word_dict.count)))
            selectedWord = word_dict[id].uppercased()
        } while (selectedWord.count > 8)
        debugPrint(selectedWord)
        return selectedWord
    }
}
